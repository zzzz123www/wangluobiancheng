# 商品详情页 - 父子组件传值项目

## 一、实现思路

### 1. 整体架构设计

本项目采用 **Vue 3 Composition API（`<script setup>`语法糖）** 实现，包含以下组件层级：

```
App.vue (根组件)
└── ProductDetail.vue (父组件 - 商品详情页)
    ├── PromotionTag.vue (子组件1 - 促销标签)
    └── Countdown.vue (子组件2 - 倒计时)
```

### 2. 父向子组件传值原理

**核心机制：使用 Vue 的 `props` 属性实现单向数据流**

```
父组件 (ProductDetail)          子组件 (PromotionTag/Countdown)
┌──────────────────┐            ┌─────────────────────┐
│   product 数据    │  ─props──> │   defineProps() 接收 │
│                  │            │                     │
│ <PromotionTag     │            │ 使用 props 数据渲染  │
│  :promotions=     │            └─────────────────────┘
│   "product.promo"> │
│ />                │
│                   │            ┌─────────────────────┐
│ <Countdown        │            │   defineProps() 接收 │
│  :endTime="..."   │ ─props──> │                     │
│  :promotionName=" │            │ 使用 props 数据渲染  │
│   "...">          │            └─────────────────────┘
│ />                │
└──────────────────┘
```

### 3. 各组件职责

#### ProductDetail.vue（父组件）
- **数据源**：定义商品信息（名称、价格、促销信息等）
- **传递方式**：通过自定义属性 `:属性名="数据"` 将数据传给子组件

```vue
<!-- 向 PromotionTag 传递促销标签数组 -->
<PromotionTag :promotions="product.promotions" />

<!-- 向 Countdown 传递结束时间和活动名称 -->
<Countdown 
  :endTime="product.promotionEndTime" 
  :promotionName="product.promotionName" 
/>
```

#### PromotionTag.vue（子组件 - 促销标签）
- **接收数据**：通过 `defineProps()` 声明接收的 props
- **数据处理**：使用 `computed` 计算属性过滤不同类型的促销信息
- **渲染展示**：根据类型分别渲染标签和高亮提示

```javascript
const props = defineProps({
  promotions: {
    type: Array,
    required: true,    // 必传验证
    default: () => []  // 默认值
  }
})
```

#### Countdown.vue（子组件 - 倒计时）
- **接收数据**：接收结束时间（ISO字符串）和活动名称
- **功能实现**：
  - 使用 `setInterval` 每秒计算剩余时间
  - 动态显示天、时、分、秒
  - 组件卸载时清除定时器（防止内存泄漏）

```javascript
const props = defineProps({
  endTime: {
    type: String,
    required: true
  },
  promotionName: {
    type: String,
    default: '限时促销'
  }
})
```

### 4. 关键技术点总结

| 技术点 | 说明 |
|--------|------|
| `defineProps()` | Vue 3 编译器宏，声明组件接收的 props |
| `reactive()` | 响应式对象，用于商品数据和倒计时数据 |
| `computed()` | 计算属性，用于派生状态（如过滤促销类型） |
| `onMounted/onUnmounted` | 生命周期钩子，管理定时器的创建与清理 |
| 单向数据流 | 数据从父组件流向子组件，保持可预测性 |

---

## 二、运行步骤

### 方式一：本地开发运行

```bash
# 1. 进入项目目录
cd "c:\Users\admin\Desktop\新建文件夹 (3)"

# 2. 安装依赖
npm install

# 3. 启动开发服务器
npm run dev

# 4. 浏览器访问显示的地址（通常是 http://localhost:5173）
```

### 方式二：直接预览构建版本

```bash
# 1. 安装依赖
npm install

# 2. 构建
npm run build

# 3. 预览
npm run preview
```

## 三、项目文件结构

```
新建文件夹 (3)/
├── index.html              # HTML 入口
├── package.json            # 项目配置和依赖
├── vite.config.js          # Vite 构建配置
├── README.md               # 本说明文档
└── src/
    ├── main.js             # 应用入口
    ├── App.vue             # 根组件
    └── components/
        ├── ProductDetail.vue    # 父组件 - 商品详情页
        ├── PromotionTag.vue     # 子组件 - 促销标签
        └── Countdown.vue        # 子组件 - 倒计时
```

## 四、运行截图说明

启动项目后，你将看到：

1. **商品详情区域**：展示商品图片、名称、描述、价格信息
2. **促销标签区**：彩色标签展示各类优惠信息（满减、新人专享、包邮等）
3. **倒计时区域**：红色背景的倒计时模块，实时显示距离活动结束的剩余时间（天:时:分:秒格式），每秒自动更新

---

## 五、Git 提交到远程仓库

```bash
# 初始化 Git 仓库
git init

# 添加所有文件
git add .

# 创建提交
git commit -m "feat: 商品详情页父子组件传值实现"

# 添加远程仓库（替换为你的仓库地址）
git remote add origin https://gitee.com/your-username/product-detail-app.git
# 或 GitHub:
# git remote add origin https://github.com/your-username/product-detail-app.git

# 推送到远程
git push -u origin main
```
