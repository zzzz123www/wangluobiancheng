<template>
  <div class="app-container">
    <ProductDetail />
  </div>
</template>

<script setup>
import ProductDetail from './components/ProductDetail.vue'
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  background-color: #f5f5f5;
}

.app-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}
</style>
