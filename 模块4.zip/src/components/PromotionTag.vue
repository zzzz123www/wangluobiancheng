<template>
  <div class="promotion-tag">
    <!-- 促销标签列表 -->
    <div class="tag-list">
      <span
        v-for="item in filteredTags"
        :key="item.id"
        class="tag-item"
        :style="{ backgroundColor: item.color }"
      >
        {{ item.text }}
      </span>
    </div>

    <!-- 高亮提示信息 -->
    <div
      v-for="item in filteredHighlights"
      :key="item.id"
      class="highlight-text"
      :style="{ backgroundColor: item.bgColor }"
    >
      {{ item.text }}
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'

// 接收父组件传递的促销数据（props）
const props = defineProps({
  promotions: {
    type: Array,
    required: true,
    default: () => []
  }
})

// 根据类型过滤出标签类型
const filteredTags = computed(() => {
  return props.promotions.filter(item => item.type === 'tag')
})

// 根据类型过滤出高亮提示
const filteredHighlights = computed(() => {
  return props.promotions.filter(item => item.type === 'highlight')
})
</script>

<style scoped>
.promotion-tag {
  margin-top: 10px;
}

.tag-list {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.tag-item {
  display: inline-block;
  padding: 4px 12px;
  border-radius: 4px;
  font-size: 12px;
  color: #fff;
}

.highlight-text {
  margin-top: 10px;
  padding: 12px 16px;
  border-radius: 6px;
  font-size: 14px;
  color: #d48806;
  text-align: center;
  animation: pulse 2s infinite;
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.7; }
}
</style>
