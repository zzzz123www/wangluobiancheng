<template>
  <div class="countdown-container">
    <div class="countdown-header">
      <span class="promotion-name">{{ promotionName }}</span>
      <span class="countdown-label">距结束还剩</span>
    </div>

    <div class="countdown-display">
      <!-- 天 -->
      <div class="time-block">
        <span class="time-value">{{ formatTime(timeLeft.days) }}</span>
        <span class="time-unit">天</span>
      </div>
      <span class="separator">:</span>
      <!-- 时 -->
      <div class="time-block">
        <span class="time-value">{{ formatTime(timeLeft.hours) }}</span>
        <span class="time-unit">时</span>
      </div>
      <span class="separator">:</span>
      <!-- 分 -->
      <div class="time-block">
        <span class="time-value">{{ formatTime(timeLeft.minutes) }}</span>
        <span class="time-unit">分</span>
      </div>
      <span class="separator">:</span>
      <!-- 秒 -->
      <div class="time-block">
        <span class="time-value">{{ formatTime(timeLeft.seconds) }}</span>
        <span class="time-unit">秒</span>
      </div>
    </div>

    <!-- 倒计时结束提示 -->
    <div v-if="isExpired" class="expired-message">
      促销活动已结束！
    </div>
  </div>
</template>

<script setup>
import { reactive, onMounted, onUnmounted, computed } from 'vue'

// 接收父组件传递的倒计时数据（props）
const props = defineProps({
  endTime: {
    type: String,
    required: true
  },
  promotionName: {
    type: String,
    default: '限时促销'
  }
})

// 响应式时间数据
const timeLeft = reactive({
  days: 0,
  hours: 0,
  minutes: 0,
  seconds: 0
})

let timer = null

// 判断是否已过期
const isExpired = computed(() => {
  return timeLeft.days <= 0 && timeLeft.hours <= 0 &&
         timeLeft.minutes <= 0 && timeLeft.seconds <= 0
})

// 格式化时间（补零）
const formatTime = (value) => {
  return String(value).padStart(2, '0')
}

// 计算剩余时间
const calculateTimeLeft = () => {
  const now = new Date().getTime()
  const end = new Date(props.endTime).getTime()
  const diff = end - now

  if (diff > 0) {
    timeLeft.days = Math.floor(diff / (1000 * 60 * 60 * 24))
    timeLeft.hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
    timeLeft.minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
    timeLeft.seconds = Math.floor((diff % (1000 * 60)) / 1000)
  } else {
    // 倒计时结束，清零
    timeLeft.days = 0
    timeLeft.hours = 0
    timeLeft.minutes = 0
    timeLeft.seconds = 0
    if (timer) {
      clearInterval(timer)
      timer = null
    }
  }
}

// 组件挂载时启动倒计时
onMounted(() => {
  calculateTimeLeft() // 立即执行一次
  timer = setInterval(calculateTimeLeft, 1000) // 每秒更新
})

// 组件卸载时清除定时器（防止内存泄漏）
onUnmounted(() => {
  if (timer) {
    clearInterval(timer)
  }
})
</script>

<style scoped>
.countdown-container {
  margin-top: 15px;
  padding: 16px;
  background: linear-gradient(135deg, #ff6b6b 0%, #ee5a5a 100%);
  border-radius: 8px;
}

.countdown-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.promotion-name {
  font-size: 18px;
  font-weight: bold;
  color: #fff;
}

.countdown-label {
  font-size: 14px;
  color: rgba(255, 255, 255, 0.9);
}

.countdown-display {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
}

.time-block {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: rgba(0, 0, 0, 0.2);
  border-radius: 6px;
  padding: 8px 12px;
  min-width: 50px;
}

.time-value {
  font-size: 28px;
  font-weight: bold;
  color: #fff;
  line-height: 1.2;
}

.time-unit {
  font-size: 11px;
  color: rgba(255, 255, 255, 0.8);
  margin-top: 2px;
}

.separator {
  font-size: 24px;
  font-weight: bold;
  color: #fff;
  margin: 0 2px;
}

.expired-message {
  text-align: center;
  padding: 10px;
  background-color: rgba(0, 0, 0, 0.2);
  border-radius: 4px;
  color: #fff;
  font-size: 14px;
  font-weight: bold;
}
</style>
