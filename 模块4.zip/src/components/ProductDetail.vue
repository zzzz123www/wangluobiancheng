<template>
  <div class="product-detail">
    <h1 class="page-title">商品详情页</h1>
    
    <div class="product-card">
      <!-- 商品图片区域 -->
      <div class="product-image">
        <img src="https://via.placeholder.com/300x300?text=商品图片" alt="商品图片" />
      </div>

      <!-- 商品信息区域 -->
      <div class="product-info">
        <h2 class="product-name">{{ product.name }}</h2>
        <p class="product-desc">{{ product.description }}</p>

        <!-- 价格区域 -->
        <div class="price-section">
          <span class="current-price">¥{{ product.price }}</span>
          <span class="original-price">¥{{ product.originalPrice }}</span>
          <span class="discount-tag">{{ product.discount }}折</span>
        </div>

        <!-- 父组件向子组件传递促销数据 -->
        <PromotionTag :promotions="product.promotions" />

        <!-- 父组件向子组件传递倒计时数据 -->
        <Countdown :endTime="product.promotionEndTime" :promotionName="product.promotionName" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { reactive } from 'vue'
import PromotionTag from './PromotionTag.vue'
import Countdown from './Countdown.vue'

// 商品数据（包含促销信息）- 这是父组件的数据源
const product = reactive({
  name: '高端智能手机 Pro Max',
  description: '全新旗舰机型，搭载最新处理器，超长续航，拍照神器',
  price: '5999.00',
  originalPrice: '7999.00',
  discount: '7.5',
  promotionName: '限时秒杀',
  promotionEndTime: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // 24小时后结束
  // 促销标签数据
  promotions: [
    { id: 1, type: 'tag', text: '满500减50', color: '#ff4d4f' },
    { id: 2, type: 'tag', text: '新人专享', color: '#ff7a45' },
    { id: 3, type: 'tag', text: '包邮', color: '#52c41a' },
    { id: 4, type: 'tag', text: '7天无理由', color: '#1890ff' },
    { id: 5, type: 'highlight', text: '限时特惠，仅剩最后100件！', bgColor: '#fff7e6' }
  ]
})
</script>

<style scoped>
.product-detail {
  background-color: #fff;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
}

.page-title {
  text-align: center;
  padding: 20px;
  font-size: 24px;
  color: #333;
  border-bottom: 1px solid #f0f0f0;
}

.product-card {
  display: flex;
  padding: 20px;
  gap: 30px;
}

.product-image {
  flex-shrink: 0;
}

.product-image img {
  width: 280px;
  height: 280px;
  border-radius: 8px;
  object-fit: cover;
}

.product-info {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.product-name {
  font-size: 22px;
  font-weight: bold;
  color: #333;
}

.product-desc {
  font-size: 14px;
  color: #666;
  line-height: 1.5;
}

.price-section {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 0;
}

.current-price {
  font-size: 28px;
  font-weight: bold;
  color: #ff4d4f;
}

.original-price {
  font-size: 16px;
  color: #999;
  text-decoration: line-through;
}

.discount-tag {
  background-color: #ff4d4f;
  color: #fff;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 12px;
}

@media (max-width: 600px) {
  .product-card {
    flex-direction: column;
    align-items: center;
  }
}
</style>
