-- ============================================
-- 电商数据库 - 订单模块 建表脚本
-- 基于 SpringBoot3 + MyBatis Plus 实现
-- ============================================

CREATE DATABASE IF NOT EXISTS `ecommerce` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `ecommerce`;

-- ----------------------------
-- 订单主表
-- ----------------------------
DROP TABLE IF EXISTS `order_info`;
CREATE TABLE `order_info` (
    `id`              BIGINT       NOT NULL AUTO_INCREMENT COMMENT '订单ID（主键）',
    `order_no`        VARCHAR(64)  NOT NULL COMMENT '订单编号（业务唯一键）',
    `user_id`         BIGINT       NOT NULL COMMENT '用户ID',
    `username`        VARCHAR(50)  NOT NULL DEFAULT '' COMMENT '下单用户名',
    `total_amount`    DECIMAL(12,2) NOT NULL COMMENT '订单总金额（元）',
    `pay_amount`      DECIMAL(12,2) NOT NULL COMMENT '实付金额（元）',
    `freight_amount`  DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '运费（元）',
    `discount_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '优惠减免（元）',
    `order_status`    TINYINT      NOT NULL DEFAULT 0 COMMENT '订单状态：0待付款 1已付款 2已发货 3已完成 4已取消 5退款中 6已退款',
    `pay_type`        TINYINT      NULL     DEFAULT NULL COMMENT '支付方式：1支付宝 2微信 3银行卡',
    `pay_time`        DATETIME     NULL     DEFAULT NULL COMMENT '支付时间',
    `delivery_time`   DATETIME     NULL     DEFAULT NULL COMMENT '发货时间',
    `receive_time`    DATETIME     NULL     DEFAULT NULL COMMENT '确认收货时间',
    `finish_time`     DATETIME     NULL     DEFAULT NULL COMMENT '订单完成时间',
    `cancel_time`     DATETIME     NULL     DEFAULT NULL COMMENT '取消时间',
    `cancel_reason`   VARCHAR(255) NULL     DEFAULT NULL COMMENT '取消原因',
    `receiver_name`   VARCHAR(50)  NOT NULL COMMENT '收货人姓名',
    `receiver_phone`  VARCHAR(20)  NOT NULL COMMENT '收货人手机号',
    `receiver_province` VARCHAR(50) NOT NULL DEFAULT '' COMMENT '省',
    `receiver_city`   VARCHAR(50)  NOT NULL DEFAULT '' COMMENT '市',
    `receiver_district`VARCHAR(50) NOT NULL DEFAULT '' COMMENT '区/县',
    `receiver_address` VARCHAR(255) NOT NULL DEFAULT '' COMMENT '详细地址',
    `remark`          VARCHAR(500) NULL     DEFAULT NULL COMMENT '订单备注',
    `source`          TINYINT      NOT NULL DEFAULT 1 COMMENT '订单来源：1PC端 2APP端 3小程序',
    `version`         INT          NOT NULL DEFAULT 0 COMMENT '乐观锁版本号',
    `deleted`         TINYINT      NOT NULL DEFAULT 0 COMMENT '逻辑删除：0未删 1已删',
    `create_time`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_order_no` (`order_no`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_order_status` (`order_status`),
    KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='电商订单主表';

-- ----------------------------
-- 订单商品明细表
-- ----------------------------
DROP TABLE IF EXISTS `order_item`;
CREATE TABLE `order_item` (
    `id`              BIGINT       NOT NULL AUTO_INCREMENT COMMENT '明细ID（主键）',
    `order_id`        BIGINT       NOT NULL COMMENT '订单ID（关联 order_info.id）',
    `order_no`        VARCHAR(64)  NOT NULL COMMENT '订单编号',
    `product_id`      BIGINT       NOT NULL COMMENT '商品ID',
    `product_name`    VARCHAR(200) NOT NULL COMMENT '商品名称',
    `product_image`   VARCHAR(500) NULL     DEFAULT NULL COMMENT '商品图片URL',
    `sku_id`          BIGINT       NULL     DEFAULT NULL COMMENT '规格SKU ID',
    `sku_name`        VARCHAR(200) NULL     DEFAULT NULL COMMENT '规格名称（如：红色/L）',
    `unit_price`      DECIMAL(10,2) NOT NULL COMMENT '商品单价（元）',
    `quantity`        INT          NOT NULL DEFAULT 1 COMMENT '购买数量',
    `total_price`     DECIMAL(12,2) NOT NULL COMMENT '小计金额（单价×数量）',
    `deleted`         TINYINT      NOT NULL DEFAULT 0 COMMENT '逻辑删除：0未删 1已删',
    `create_time`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_order_id` (`order_id`),
    KEY `idx_order_no` (`order_no`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='订单商品明细表';

-- ----------------------------
-- 插入测试数据
-- ----------------------------
INSERT INTO `order_info`
(`order_no`, `user_id`, `username`, `total_amount`, `pay_amount`, `freight_amount`,
 `discount_amount`, `order_status`, `pay_type`, `pay_time`, `delivery_time`, `receive_time`,
 `receiver_name`, `receiver_phone`, `receiver_province`, `receiver_city`, `receiver_district`,
 `receiver_address`, `source`) VALUES
('ORD202405280001', 1001, '张三', 299.00, 279.00, 10.00, 30.00, 3, 1, '2024-05-28 10:30:00', '2024-05-28 14:20:00', '2024-06-01 09:15:00', '张三', '13800138001', '广东省', '深圳市', '南山区', '科技园路1号', 1),
('ORD202405290002', 1002, '李四', 1599.00, 1549.00, 0.00, 50.00, 2, 2, '2024-05-29 09:15:00', '2024-05-29 16:00:00', NULL, '李四', '13900139002', '北京市', '北京市', '朝阳区', '建国路88号', 2),
('ORD202406010003', 1001, '张三', 89.00, 89.00, 0.00, 0.00, 0, NULL, NULL, NULL, NULL, '张三', '13800138001', '广东省', '深圳市', '南山区', '科技园路1号', 1),
('ORD202406020004', 1003, '王五', 4599.00, 4499.00, 0.00, 100.00, 1, 1, '2024-06-02 11:45:00', NULL, NULL, '王五', '13700137003', '上海市', '上海市', '浦东新区', '陆家嘴环路100号', 3),
('ORD202406050005', 1002, '李四', 199.00, 0.00, 0.00, 0.00, 4, NULL, NULL, NULL, NULL, '李四', '13900139002', '北京市', '北京市', '朝阳区', '建国路88号', 2),
('ORD202406100006', 1004, '赵六', 2588.00, 2488.00, 0.00, 100.00, 3, 2, '2024-06-10 08:20:00', '2024-06-10 15:30:00', '2024-06-13 10:00:00', '赵六', '13600136004', '浙江省', '杭州市', '西湖区', '文三路269号', 3);

INSERT INTO `order_item`
(`order_id`, `order_no`, `product_id`, `product_name`, `sku_name`, `unit_price`, `quantity`, `total_price`) VALUES
(1, 'ORD202405280001', 2001, '无线蓝牙耳机Pro', '星空黑', 159.00, 1, 159.00),
(1, 'ORD202405280001', 2005, '手机壳保护套', '透明款', 19.90, 6, 119.40),
(2, 'ORD202405290002', 3001, '智能手表S8', '银色/42mm', 1549.00, 1, 1549.00),
(3, 'ORD202406010003', 2010, '数据线Type-C快充', '1.5米/白色', 29.00, 1, 29.00),
(3, 'ORD202406010003', 2011, '手机支架桌面', '折叠款黑色', 59.99, 1, 59.99),
(4, 'ORD202406020004', 4001, '游戏笔记本RTX4060', 'i7/16G/512G', 4499.00, 1, 4499.00),
(5, 'ORD202406050005', 2050, '运动水杯500ml', '蓝色', 199.00, 1, 199.00),
(6, 'ORD202406100006', 3002, '降噪耳机WH-1000', '黑色', 1899.00, 1, 1899.00),
(6, 'ORD202406100006', 2002, '蓝牙音箱Mini', '白色', 589.00, 1, 589.00);
