-- ============================================================
--  电商购物平台 - 用户认证模块 SQL
--  包含：用户表(sys_user) + 测试数据
-- ============================================================

CREATE DATABASE IF NOT EXISTS ecommerce DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE ecommerce;

-- -----------------------------------------------------------
--  用户表
-- -----------------------------------------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
    `id`          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '用户ID（主键）',
    `username`    VARCHAR(50)  NOT NULL                COMMENT '用户名（登录账号，唯一）',
    `password`    VARCHAR(128) NOT NULL DEFAULT ''      COMMENT '密码（BCrypt加密）',
    `nickname`    VARCHAR(50)           DEFAULT ''      COMMENT '昵称/显示名',
    `phone`       VARCHAR(20)           DEFAULT ''      COMMENT '手机号',
    `email`       VARCHAR(100)          DEFAULT ''      COMMENT '邮箱',
    `avatar`      VARCHAR(500)          DEFAULT ''      COMMENT '头像URL',
    `status`      TINYINT               DEFAULT 1       COMMENT '状态：0禁用 1启用',
    `role`        TINYINT               DEFAULT 0       COMMENT '角色：0普通用户 1管理员 2运营',
    `last_login_time` DATETIME           DEFAULT NULL   COMMENT '最后登录时间',
    `last_login_ip`   VARCHAR(50)        DEFAULT ''     COMMENT '最后登录IP',
    `create_time` DATETIME              DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME              DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_username` (`username`),
    KEY `idx_phone` (`phone`),
    KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='系统用户表';

-- -----------------------------------------------------------
--  插入测试数据
--  默认密码均为 123456（明文，用于测试）
-- -----------------------------------------------------------
INSERT INTO `sys_user` (username, password, nickname, phone, email, avatar, status, role) VALUES
('admin', '123456', '超级管理员', '13800000001', 'admin@ecommerce.com', '', 1, 1),
('zhangsan', '123456', '张三', '13800000002', 'zhangsan@163.com', '', 1, 0),
('lisi', '123456', '李四', '13800000003', 'lisi@qq.com', '', 1, 0),
('wangwu', '123456', '王五', '13800000004', 'wangwu@gmail.com', '', 1, 0),
('operator1', '123456', '运营小美', '13800000005', 'operator@ecommerce.com', '', 1, 2);
