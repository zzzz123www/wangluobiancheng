package com.ecommerce.order.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.ecommerce.order.dto.AddOrderDTO;
import com.ecommerce.order.dto.OrderQueryDTO;
import com.ecommerce.order.dto.UpdateOrderDTO;
import com.ecommerce.order.entity.OrderInfo;

/**
 * 订单服务接口
 */
public interface IOrderService {

    /**
     * 新增订单（含明细）
     * @param dto 订单信息
     * @return 新增后的订单
     */
    OrderInfo add(AddOrderDTO dto);

    /**
     * 根据ID查询订单详情（含商品明细）
     * @param id 订单ID
     * @return 订单详情
     */
    OrderInfo getDetailById(Long id);

    /**
     * 根据订单编号查询
     * @param orderNo 订单编号
     * @return 订单详情
     */
    OrderInfo getByOrderNo(String orderNo);

    /**
     * 分页条件查询订单列表
     * @param query 查询条件
     * @return 分页结果
     */
    IPage<OrderInfo> queryPage(OrderQueryDTO query);

    /**
     * 修改订单信息
     * @param dto 修改内容
     * @return 是否成功
     */
    boolean update(UpdateOrderDTO dto);

    /**
     * 删除订单（逻辑删除）
     * @param id 订单ID
     * @return 是否成功
     */
    boolean delete(Long id);

    /**
     * 批量删除订单（逻辑删除）
     * @param ids ID列表
     * @return 是否成功
     */
    boolean deleteBatch(Long[] ids);
}
