package com.ecommerce.order.service;

import com.ecommerce.order.dto.LoginDTO;
import com.ecommerce.order.dto.LoginVO;
import com.ecommerce.order.entity.UserInfo;

/**
 * 用户服务接口
 */
public interface IUserService {

    /**
     * 用户登录
     *
     * @param dto 登录参数（用户名 + 密码）
     * @return 登录成功信息（含 Token），失败抛异常
     */
    LoginVO login(LoginDTO dto);

    /**
     * 根据 ID 查询用户
     *
     * @param userId 用户ID
     * @return 用户信息
     */
    UserInfo getById(Long userId);

    /**
     * 根据用户名查询用户（用于登录校验）
     *
     * @param username 用户名
     * @return 用户信息
     */
    UserInfo getByUsername(String username);
}
