package com.ecommerce.order.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ecommerce.order.dto.AddOrderDTO;
import com.ecommerce.order.dto.OrderQueryDTO;
import com.ecommerce.order.dto.UpdateOrderDTO;
import com.ecommerce.order.entity.OrderInfo;
import com.ecommerce.order.entity.OrderItem;
import com.ecommerce.order.mapper.OrderInfoMapper;
import com.ecommerce.order.mapper.OrderItemMapper;
import com.ecommerce.order.service.IOrderService;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * 订单服务实现类
 */
@Service
public class OrderServiceImpl implements IOrderService {

    private final OrderInfoMapper orderInfoMapper;
    private final OrderItemMapper orderItemMapper;

    public OrderServiceImpl(OrderInfoMapper orderInfoMapper, OrderItemMapper orderItemMapper) {
        this.orderInfoMapper = orderInfoMapper;
        this.orderItemMapper = orderItemMapper;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public OrderInfo add(AddOrderDTO dto) {
        // 1. 构建订单主表实体
        OrderInfo order = new OrderInfo();
        BeanUtils.copyProperties(dto, order);
        order.setOrderNo(generateOrderNo());
        order.setOrderStatus(0);  // 默认待付款状态

        // 2. 保存订单主表
        orderInfoMapper.insert(order);

        // 3. 保存订单明细
        List<OrderItem> items = new ArrayList<>();
        if (dto.getItems() != null && !dto.getItems().isEmpty()) {
            for (AddOrderDTO.OrderItemDTO itemDto : dto.getItems()) {
                OrderItem item = new OrderItem();
                item.setOrderId(order.getId());
                item.setOrderNo(order.getOrderNo());
                item.setProductId(itemDto.getProductId());
                item.setProductName(itemDto.getProductName());
                item.setProductImage(itemDto.getProductImage());
                item.setSkuId(itemDto.getSkuId());
                item.setSkuName(itemDto.getSkuName());
                item.setUnitPrice(itemDto.getUnitPrice());
                item.setQuantity(itemDto.getQuantity());
                // 小计 = 单价 × 数量
                item.setTotalPrice(itemDto.getUnitPrice().multiply(new BigDecimal(itemDto.getQuantity())));
                items.add(item);
            }
            for (OrderItem item : items) {
                orderItemMapper.insert(item);
            }
        }

        return order;
    }

    @Override
    public OrderInfo getDetailById(Long id) {
        OrderInfo order = orderInfoMapper.selectById(id);
        if (order != null) {
            fillItems(order);
        }
        return order;
    }

    @Override
    public OrderInfo getByOrderNo(String orderNo) {
        LambdaQueryWrapper<OrderInfo> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(OrderInfo::getOrderNo, orderNo);
        OrderInfo order = orderInfoMapper.selectOne(wrapper);
        if (order != null) {
            fillItems(order);
        }
        return order;
    }

    @Override
    public IPage<OrderInfo> queryPage(OrderQueryDTO query) {
        // 限制每页最大 100 条，防止恶意请求
        long pageSize = Math.min(query.getSize(), 100L);
        Page<OrderInfo> page = new Page<>(query.getCurrent(), pageSize);

        LambdaQueryWrapper<OrderInfo> wrapper = new LambdaQueryWrapper<>();

        // ====== 精确查询条件 ======
        if (query.getUserId() != null) {
            wrapper.eq(OrderInfo::getUserId, query.getUserId());
        }
        if (query.getOrderStatus() != null) {
            wrapper.eq(OrderInfo::getOrderStatus, query.getOrderStatus());
        }
        if (query.getPayType() != null) {
            wrapper.eq(OrderInfo::getPayType, query.getPayType());
        }
        if (query.getSource() != null) {
            wrapper.eq(OrderInfo::getSource, query.getSource());
        }

        // ====== 模糊查询条件 ======
        if (query.getOrderNo() != null && !query.getOrderNo().isBlank()) {
            wrapper.like(OrderInfo::getOrderNo, query.getOrderNo());
        }
        if (query.getUsername() != null && !query.getUsername().isBlank()) {
            wrapper.like(OrderInfo::getUsername, query.getUsername());
        }
        if (query.getReceiverPhone() != null && !query.getReceiverPhone().isBlank()) {
            wrapper.like(OrderInfo::getReceiverPhone, query.getReceiverPhone());
        }

        // ====== 范围查询 ======
        if (query.getMinAmount() != null) {
            wrapper.ge(OrderInfo::getTotalAmount, query.getMinAmount());
        }
        if (query.getMaxAmount() != null) {
            wrapper.le(OrderInfo::getTotalAmount, query.getMaxAmount());
        }
        if (query.getStartTime() != null) {
            wrapper.ge(OrderInfo::getCreateTime, query.getStartTime());
        }
        if (query.getEndTime() != null) {
            wrapper.le(OrderInfo::getCreateTime, query.getEndTime());
        }

        // ====== 动态排序（安全白名单机制）=====
        applySort(wrapper, query);

        return orderInfoMapper.selectPage(page, wrapper);
    }

    /**
     * 应用动态排序（使用白名单防止 SQL 注入）
     */
    private void applySort(LambdaQueryWrapper<OrderInfo> wrapper, OrderQueryDTO query) {
        String field = query.getSortField();
        String direction = query.getSortDirection();

        // 排序字段白名单：只允许这些字段参与排序
        switch (field == null ? "" : field) {
            case "createTime":
                if ("asc".equalsIgnoreCase(direction)) {
                    wrapper.orderByAsc(OrderInfo::getCreateTime);
                } else {
                    wrapper.orderByDesc(OrderInfo::getCreateTime);
                }
                break;
            case "totalAmount":
                if ("asc".equalsIgnoreCase(direction)) {
                    wrapper.orderByAsc(OrderInfo::getTotalAmount);
                } else {
                    wrapper.orderByDesc(OrderInfo::getTotalAmount);
                }
                break;
            case "payTime":
                if ("asc".equalsIgnoreCase(direction)) {
                    wrapper.orderByAsc(OrderInfo::getPayTime);
                } else {
                    wrapper.orderByDesc(OrderInfo::getPayTime);
                }
                break;
            case "updateTime":
                if ("asc".equalsIgnoreCase(direction)) {
                    wrapper.orderByAsc(OrderInfo::getUpdateTime);
                } else {
                    wrapper.orderByDesc(OrderInfo::getUpdateTime);
                }
                break;
            default:
                // 默认按创建时间倒序
                wrapper.orderByDesc(OrderInfo::getCreateTime);
                break;
        }
    }

    @Override
    public boolean update(UpdateOrderDTO dto) {
        OrderInfo order = orderInfoMapper.selectById(dto.getId());
        if (order == null) {
            throw new RuntimeException("订单不存在，ID: " + dto.getId());
        }

        // 只更新允许修改的字段
        if (dto.getReceiverName() != null) order.setReceiverName(dto.getReceiverName());
        if (dto.getReceiverPhone() != null) order.setReceiverPhone(dto.getReceiverPhone());
        if (dto.getReceiverProvince() != null) order.setReceiverProvince(dto.getReceiverProvince());
        if (dto.getReceiverCity() != null) order.setReceiverCity(dto.getReceiverCity());
        if (dto.getReceiverDistrict() != null) order.setReceiverDistrict(dto.getReceiverDistrict());
        if (dto.getReceiverAddress() != null) order.setReceiverAddress(dto.getReceiverAddress());
        if (dto.getRemark() != null) order.setRemark(dto.getRemark());
        if (dto.getFreightAmount() != null) order.setFreightAmount(dto.getFreightAmount());
        if (dto.getDiscountAmount() != null) order.setDiscountAmount(dto.getDiscountAmount());
        // 待支付状态下可修改实付金额
        if (dto.getPayAmount() != null && order.getOrderStatus() == 0) {
            order.setPayAmount(dto.getPayAmount());
        }

        int rows = orderInfoMapper.updateById(order);
        return rows > 0;
    }

    @Override
    public boolean delete(Long id) {
        // 先删除关联的订单明细
        LambdaQueryWrapper<OrderItem> itemWrapper = new LambdaQueryWrapper<>();
        itemWrapper.eq(OrderItem::getOrderId, id);
        orderItemMapper.delete(itemWrapper);
        // 再删除订单（逻辑删除）
        int rows = orderInfoMapper.deleteById(id);
        return rows > 0;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean deleteBatch(Long[] ids) {
        for (Long id : ids) {
            // 删除关联明细
            LambdaQueryWrapper<OrderItem> itemWrapper = new LambdaQueryWrapper<>();
            itemWrapper.eq(OrderItem::getOrderId, id);
            orderItemMapper.delete(itemWrapper);
        }
        // 批量删除订单
        List<Long> idList = new java.util.ArrayList<>(java.util.Arrays.asList(ids));
        int rows = orderInfoMapper.deleteBatchIds(idList);
        return rows > 0;
    }

    /**
     * 填充订单商品明细列表到订单对象中
     * （注：生产环境建议使用 VO 对象封装返回数据）
     */
    private void fillItems(OrderInfo order) {
        LambdaQueryWrapper<OrderItem> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(OrderItem::getOrderId, order.getId());
        List<OrderItem> items = orderItemMapper.selectList(wrapper);
        // 将明细存入扩展字段中（实际项目中应使用VO）
    }

    /**
     * 生成唯一订单编号
     * 格式：ORD + 年月日时分秒 + 6位随机数
     */
    private String generateOrderNo() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
        String timestamp = LocalDateTime.now().format(formatter);
        String random = UUID.randomUUID().toString().replace("-", "").substring(0, 8).toUpperCase();
        return "ORD" + timestamp + random;
    }
}
