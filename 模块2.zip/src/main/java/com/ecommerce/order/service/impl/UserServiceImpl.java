package com.ecommerce.order.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ecommerce.order.dto.LoginDTO;
import com.ecommerce.order.dto.LoginVO;
import com.ecommerce.order.entity.UserInfo;
import com.ecommerce.order.mapper.UserInfoMapper;
import com.ecommerce.order.service.IUserService;
import com.ecommerce.order.util.JwtUtil;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

/**
 * 用户服务实现类
 */
@Service
public class UserServiceImpl implements IUserService {

    private final UserInfoMapper userInfoMapper;

    public UserServiceImpl(UserInfoMapper userInfoMapper) {
        this.userInfoMapper = userInfoMapper;
    }

    @Override
    public LoginVO login(LoginDTO dto) {
        // 1. 根据用户名查询用户
        UserInfo user = getByUsername(dto.getUsername());
        if (user == null) {
            throw new RuntimeException("用户不存在");
        }

        // 2. 校验密码（此处使用简单比对，生产环境应使用 BCrypt）
        if (!dto.getPassword().equals(user.getPassword())) {
            throw new RuntimeException("密码错误");
        }

        // 3. 校验账号状态
        if (user.getStatus() == null || user.getStatus() != 1) {
            throw new RuntimeException("账号已被禁用，请联系管理员");
        }

        // 4. 更新最后登录时间和 IP
        user.setLastLoginTime(LocalDateTime.now());
        userInfoMapper.updateById(user);

        // 5. 生成 JWT Token
        String token = JwtUtil.generateToken(user.getId(), user.getUsername());

        // 6. 构建返回对象
        long expireTime = System.currentTimeMillis() + 24 * 60 * 60 * 1000L; // 24小时后
        return LoginVO.of(token, expireTime, user);
    }

    @Override
    public UserInfo getById(Long userId) {
        return userInfoMapper.selectById(userId);
    }

    @Override
    public UserInfo getByUsername(String username) {
        LambdaQueryWrapper<UserInfo> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(UserInfo::getUsername, username);
        wrapper.last("LIMIT 1");
        return userInfoMapper.selectOne(wrapper);
    }
}
