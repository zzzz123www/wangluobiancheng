package com.ecommerce.order.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * JWT Token 工具类
 * 职责：生成 Token、解析 Token、验证 Token 有效性
 *
 * Token 结构（三段式）：
 *   Header.Payload.Signature
 *   - Header: 算法类型 (HS256)
 *   - Payload: 用户ID、用户名、角色、签发时间、过期时间
 *   - Signature: HMAC-SHA256 签名（防篡改）
 */
public class JwtUtil {

    /** 签名密钥（生产环境应从配置中心或环境变量读取） */
    private static final String SECRET_KEY = "EcommerceOrderModuleJwtSecretKey2024!@#$%";

    /** Token 默认有效期：24 小时 */
    private static final long EXPIRE_TIME = 24 * 60 * 60 * 1000L;

    /**
     * 生成密钥对象
     */
    private static SecretKey getSigningKey() {
        return Keys.hmacShaKeyFor(SECRET_KEY.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * 生成 JWT Token
     *
     * @param userId   用户ID
     * @param username 用户名
     * @return JWT Token 字符串
     */
    public static String generateToken(Long userId, String username) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("userId", userId);
        claims.put("username", username);

        return Jwts.builder()
                .claims(claims)
                .subject(String.valueOf(userId))
                .id(UUID.randomUUID().toString().replace("-", ""))
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + EXPIRE_TIME))
                .signWith(getSigningKey())
                .compact();
    }

    /**
     * 解析 Token 获取 Claims
     *
     * @param token JWT Token
     * @return Claims（包含用户信息），Token 无效时返回 null
     */
    public static Claims parseToken(String token) {
        try {
            return Jwts.parser()
                    .verifyWith(getSigningKey())
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 从 Token 中获取用户ID
     */
    public static Long getUserId(String token) {
        Claims claims = parseToken(token);
        if (claims != null && claims.get("userId") != null) {
            return Number.valueOf(claims.get("userId").toString()).longValue();
        }
        return null;
    }

    /**
     * 从 Token 中获取用户名
     */
    public static String getUsername(String token) {
        Claims claims = parseToken(token);
        if (claims != null) {
            return claims.get("username", String.class);
        }
        return null;
    }

    /**
     * 验证 Token 是否有效（未过期且签名正确）
     */
    public static boolean validateToken(String token) {
        try {
            Claims claims = parseToken(token);
            if (claims == null) {
                return false;
            }
            // 检查是否过期
            return !claims.getExpiration().before(new Date());
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 检查 Token 是否即将过期（剩余时间 < 1小时，用于前端自动刷新）
     */
    public boolean isTokenExpiringSoon(String token) {
        Claims claims = parseToken(token);
        if (claims == null) {
            return true;
        }
        long remaining = claims.getExpiration().getTime() - System.currentTimeMillis();
        return remaining < 60 * 60 * 1000L; // 小于1小时
    }
}
