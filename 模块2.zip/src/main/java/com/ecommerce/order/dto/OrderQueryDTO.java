package com.ecommerce.order.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 订单查询条件 DTO（增强版）
 * 支持多条件组合筛选 + 排序
 */
@Data
public class OrderQueryDTO {

    /** 当前页码（默认1） */
    private Long current = 1L;

    /** 每页大小（默认10，最大100） */
    private Long size = 10L;

    // ==================== 精确查询条件 ====================

    /** 用户ID */
    private Long userId;

    /** 订单状态：0待付款 1已付款 2已发货 3已完成 4已取消 5退款中 6已退款 */
    private Integer orderStatus;

    /** 支付方式：1支付宝 2微信 3银行卡 */
    private Integer payType;

    /** 订单来源：1PC端 2APP端 3小程序 */
    private Integer source;

    // ==================== 模糊查询条件 ====================

    /** 订单编号（模糊匹配） */
    private String orderNo;

    /** 用户名/收货人姓名（模糊匹配） */
    private String username;

    /** 收货人手机号（模糊匹配） */
    private String receiverPhone;

    // ==================== 范围查询条件 ====================

    /** 最小金额 */
    private BigDecimal minAmount;

    /** 最大金额 */
    private BigDecimal maxAmount;

    /** 创建时间-开始 */
    private LocalDateTime startTime;

    /** 创建时间-结束 */
    private LocalDateTime endTime;

    // ==================== 排序参数 ====================

    /**
     * 排序字段（驼峰命名，自动转下划线）
     * 可选值：createTime, payTime, totalAmount, updateTime
     * 默认：createTime（按创建时间倒序）
     */
    private String sortField = "createTime";

    /**
     * 排序方向：asc（升序）/ desc（降序，默认）
     */
    private String sortDirection = "desc";
}
