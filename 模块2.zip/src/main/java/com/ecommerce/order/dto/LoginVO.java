package com.ecommerce.order.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 登录成功响应 DTO（返回 Token 和用户基本信息）
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginVO {

    /** JWT Token */
    private String token;

    /** Token 类型 */
    private String tokenType = "Bearer";

    /** 过期时间（毫秒时间戳） */
    private Long expireTime;

    /** 用户ID */
    private Long userId;

    /** 用户名 */
    private String username;

    /** 昵称 */
    private String nickname;

    /** 头像 */
    private String avatar;

    /**
     * 快捷构建方法
     */
    public static LoginVO of(String token, Long expireTime, UserInfo userInfo) {
        LoginVO vo = new LoginVO();
        vo.setToken(token);
        vo.setExpireTime(expireTime);
        vo.setUserId(userInfo.getId());
        vo.setUsername(userInfo.getUsername());
        vo.setNickname(userInfo.getNickname());
        vo.setAvatar(userInfo.getAvatar());
        return vo;
    }
}
