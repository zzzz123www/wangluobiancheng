package com.ecommerce.order.dto;

import lombok.Data;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

/**
 * 新增订单请求 DTO
 */
@Data
public class AddOrderDTO {

    /** 用户ID */
    @NotNull(message = "用户ID不能为空")
    private Long userId;

    /** 下单用户名 */
    @NotBlank(message = "用户名不能为空")
    private String username;

    /** 订单总金额 */
    @NotNull(message = "订单总金额不能为空")
    private BigDecimal totalAmount;

    /** 实付金额 */
    @NotNull(message = "实付金额不能为空")
    private BigDecimal payAmount;

    /** 运费（默认0） */
    private BigDecimal freightAmount = BigDecimal.ZERO;

    /** 优惠减免（默认0） */
    private BigDecimal discountAmount = BigDecimal.ZERO;

    /** 支付方式：1支付宝 2微信 3银行卡 */
    private Integer payType;

    /** 收货人姓名 */
    @NotBlank(message = "收货人不能为空")
    private String receiverName;

    /** 收货人手机号 */
    @NotBlank(message = "收货人电话不能为空")
    private String receiverPhone;

    /** 省 */
    private String receiverProvince;

    /** 市 */
    private String receiverCity;

    /** 区/县 */
    private String receiverDistrict;

    /** 详细地址 */
    @NotBlank(message = "详细地址不能为空")
    private String receiverAddress;

    /** 订单备注 */
    private String remark;

    /** 订单来源（默认1 PC端） */
    private Integer source = 1;

    /** 订单商品明细列表 */
    @NotNull(message = "订单商品不能为空")
    private List<OrderItemDTO> items;

    /**
     * 订单商品明细内部类
     */
    @Data
    public static class OrderItemDTO {
        /** 商品ID */
        @NotNull(message = "商品ID不能为空")
        private Long productId;
        /** 商品名称 */
        @NotBlank(message = "商品名称不能为空")
        private String productName;
        /** 商品图片URL */
        private String productImage;
        /** SKU ID */
        private Long skuId;
        /** 规格名称 */
        private String skuName;
        /** 商品单价 */
        @NotNull(message = "商品单价不能为空")
        private BigDecimal unitPrice;
        /** 购买数量 */
        @NotNull(message = "购买数量不能为空")
        private Integer quantity;
    }
}
