package com.ecommerce.order.dto;

import lombok.Data;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * 修改订单请求 DTO
 */
@Data
public class UpdateOrderDTO {

    /** 订单ID（主键） */
    @NotNull(message = "订单ID不能为空")
    private Long id;

    /** 收货人姓名 */
    private String receiverName;

    /** 收货人手机号 */
    private String receiverPhone;

    /** 省 */
    private String receiverProvince;

    /** 市 */
    private String receiverCity;

    /** 区/县 */
    private String receiverDistrict;

    /** 详细地址 */
    private String receiverAddress;

    /** 订单备注 */
    private String remark;

    /** 实付金额（仅待支付状态可改） */
    private BigDecimal payAmount;

    /** 运费 */
    private BigDecimal freightAmount;

    /** 优惠减免 */
    private BigDecimal discountAmount;
}
