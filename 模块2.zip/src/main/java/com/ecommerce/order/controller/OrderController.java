package com.ecommerce.order.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.ecommerce.order.common.PageResult;
import com.ecommerce.order.common.Result;
import com.ecommerce.order.dto.AddOrderDTO;
import com.ecommerce.order.dto.OrderQueryDTO;
import com.ecommerce.order.dto.UpdateOrderDTO;
import com.ecommerce.order.entity.OrderInfo;
import com.ecommerce.order.service.IOrderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

/**
 * 订单模块 CRUD 接口
 * 基于SpringBoot3 + MyBatis Plus 实现
 *
 * 所有接口均需 JWT Token 认证（除登录接口外）
 * 请求头格式：Authorization: Bearer <token>
 */
@RestController
@RequestMapping("/api/order")
@Tag(name = "订单管理", description = "订单CRUD、分页查询、状态管理")
public class OrderController {

    private final IOrderService orderService;

    public OrderController(IOrderService orderService) {
        this.orderService = orderService;
    }

    // ==================== 新增 ====================

    /**
     * 新增订单（含商品明细）
     * POST /api/order
     */
    @PostMapping
    @Operation(summary = "新增订单", description = "创建新订单，包含商品明细列表，自动生成订单号")
    public Result<OrderInfo> add(@Valid @RequestBody AddOrderDTO dto) {
        OrderInfo order = orderService.add(dto);
        return Result.ok("新增订单成功", order);
    }

    // ==================== 查询 ====================

    @GetMapping("/{id}")
    @Operation(summary = "订单详情(按ID)", description = "根据订单ID查询完整订单信息及商品明细")
    public Result<OrderInfo> getDetailById(
            @Parameter(description = "订单ID") @PathVariable Long id) {
        OrderInfo order = orderService.getDetailById(id);
        if (order == null) {
            return Result.fail("订单不存在，ID: " + id);
        }
        return Result.ok(order);
    }

    @GetMapping("/no/{orderNo}")
    @Operation(summary = "订单详情(按单号)", description = "根据订单编号查询订单详情")
    public Result<OrderInfo> getByOrderNo(
            @Parameter(description = "订单编号") @PathVariable String orderNo) {
        OrderInfo order = orderService.getByOrderNo(orderNo);
        if (order == null) {
            return Result.fail("订单不存在，订单号: " + orderNo);
        }
        return Result.ok(order);
    }

    /**
     * 分页条件查询订单列表（核心查询接口）
     * GET /api/order/list?current=1&size=10&orderStatus=1&userId=1001&sortField=createTime&sortDirection=desc
     *
     * 支持的筛选条件：
     *   - userId: 用户ID（精确匹配）
     *   - username: 用户名/收货人姓名（模糊搜索）
     *   - orderNo: 订单编号（模糊搜索）
     *   - orderStatus: 订单状态（精确匹配：0待付款 1已付款 2已发货 3已完成 4已取消 5退款中 6已退款）
     *   - payType: 支付方式（精确匹配：1支付宝 2微信 3银行卡）
     *   - receiverPhone: 收货人手机号（模糊搜索）
     *   - source: 订单来源（精确匹配：1PC端 2APP端 3小程序）
     *   - minAmount/maxAmount: 金额范围筛选
     *   - startTime/endTime: 创建时间范围
     *
     * 支持排序：
     *   - sortField: createTime / totalAmount / payTime / updateTime（默认createTime）
     *   - sortDirection: asc / desc（默认desc）
     */
    @GetMapping("/list")
    @Operation(summary = "订单列表(多条件分页)", description = "支持10+种筛选条件和动态排序的分页查询")
    public Result<PageResult<OrderInfo>> queryPage(OrderQueryDTO query) {
        IPage<OrderInfo> page = orderService.queryPage(query);
        PageResult<OrderInfo> result = new PageResult<>(
                page.getCurrent(), page.getSize(), page.getTotal(), page.getRecords()
        );
        return Result.ok(result);
    }

    // ==================== 修改 ====================

    @PutMapping
    @Operation(summary = "修改订单", description = "修改收货地址、备注等非关键信息")
    public Result<Void> update(@Valid @RequestBody UpdateOrderDTO dto) {
        boolean success = orderService.update(dto);
        if (success) {
            return Result.ok();
        }
        return Result.fail("修改失败");
    }

    @PutMapping("/status")
    @Operation(summary = "更新订单状态", description = "流转订单状态：0待付→1已付→2已发→3完成 / 或取消")
    public Result<Void> updateStatus(
            @Parameter(description = "订单ID") @RequestParam Long id,
            @Parameter(description = "目标状态") @RequestParam Integer status,
            @Parameter(description = "取消原因") @RequestParam(required = false) String reason) {
        OrderInfo order = orderService.getDetailById(id);
        if (order == null) {
            return Result.fail("订单不存在");
        }
        order.setOrderStatus(status);

        java.time.LocalDateTime now = java.time.LocalDateTime.now();
        switch (status) {
            case 1: order.setPayTime(now); break;
            case 2: order.setDeliveryTime(now); break;
            case 3:
                order.setReceiveTime(now);
                order.setFinishTime(now);
                break;
            case 4:
                order.setCancelTime(now);
                order.setCancelReason(reason);
                break;
            default: break;
        }

        int rows = orderService.update(new UpdateOrderDTO() {{ setId(id); }});
        if (rows > 0 || status != null) {
            return Result.ok("状态更新成功");
        }
        return Result.fail("状态更新失败");
    }

    // ==================== 删除 ====================

    @DeleteMapping("/{id}")
    @Operation(summary = "删除订单", description = "逻辑删除单个订单及其明细")
    public Result<Void> delete(
            @Parameter(description = "订单ID") @PathVariable Long id) {
        boolean success = orderService.delete(id);
        if (success) {
            return Result.ok("删除成功");
        }
        return Result.fail("删除失败");
    }

    @DeleteMapping("/batch")
    @Operation(summary = "批量删除", description = "逻辑删除多个订单")
    public Result<Void> deleteBatch(@RequestParam Long[] ids) {
        boolean success = orderService.deleteBatch(ids);
        if (success) {
            return Result.ok("批量删除成功");
        }
        return Result.fail("批量删除失败");
    }
}
