package com.ecommerce.order.controller;

import com.ecommerce.order.common.Result;
import com.ecommerce.order.dto.LoginDTO;
import com.ecommerce.order.dto.LoginVO;
import com.ecommerce.order.entity.UserInfo;
import com.ecommerce.order.service.IUserService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

/**
 * 用户认证控制器
 * 处理：登录、登出、获取当前用户信息
 *
 * 注意：此类接口在 WebConfig 中被排除在 JWT 拦截之外
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final IUserService userService;

    public AuthController(IUserService userService) {
        this.userService = userService;
    }

    /**
     * 用户登录
     * POST /api/auth/login
     *
     * 请求体示例：
     * {
     *   "username": "admin",
     *   "password": "123456"
     * }
     *
     * 成功响应：
     * {
     *   "code": 200,
     *   "msg": "登录成功",
     *   "data": {
     *     "token": "eyJhbGciOiJIUzI1NiJ9...",
     *     "tokenType": "Bearer",
     *     "expireTime": 1718400000000,
     *     "userId": 1,
     *     "username": "admin",
     *     "nickname": "管理员",
     *     "avatar": ""
     *   }
     * }
     */
    @PostMapping("/login")
    public Result<LoginVO> login(@Valid @RequestBody LoginDTO dto) {
        LoginVO loginVO = userService.login(dto);
        return Result.ok("登录成功", loginVO);
    }

    /**
     * 获取当前登录用户信息
     * GET /api/auth/currentUser
     *
     * 需要在 Header 中携带 Token：Authorization: Bearer <token>
     */
    @GetMapping("/currentUser")
    public Result<UserInfo> getCurrentUser(@RequestAttribute("currentUserId") Long userId) {
        UserInfo user = userService.getById(userId);
        // 隐藏敏感信息（密码）
        if (user != null) {
            user.setPassword(null);
        }
        return Result.ok(user);
    }

    /**
     * 用户登出（客户端清除 Token 即可，后端可做 Token 黑名单）
     * POST /api/auth/logout
     */
    @PostMapping("/logout")
    public Result<Void> logout() {
        // 前端需删除本地存储的 Token
        // 后端可扩展 Redis 黑名单机制使 Token 立即失效
        return Result.ok("退出成功");
    }
}
