package com.ecommerce.order.interceptor;

import com.ecommerce.order.util.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * JWT Token 认证拦截器
 *
 * 工作原理：
 * 1. 从请求头 Authorization 中提取 Token（格式：Bearer xxx）
 * 2. 调用 JwtUtil 验证 Token 有效性（签名正确 + 未过期）
 * 3. 验证通过：将 userId 和 username 存入 request 属性，放行请求
 * 4. 验证失败：返回 401 未授权错误
 */
@Component
public class JwtAuthInterceptor implements HandlerInterceptor {

    /** 请求头中 Token 的 key */
    private static final String AUTH_HEADER = "Authorization";

    /** Token 前缀 */
    private static final String TOKEN_PREFIX = "Bearer ";

    /**
     * 请求预处理 - Token 认证
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // OPTIONS 请求直接放行（跨域预检）
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            return true;
        }

        // 1. 提取 Token
        String token = extractToken(request);
        if (token == null || token.isEmpty()) {
            sendUnauthorized(response, "未提供认证Token，请先登录");
            return false;
        }

        // 2. 验证 Token 有效性
        if (!JwtUtil.validateToken(token)) {
            sendUnauthorized(response, "Token已过期或无效，请重新登录");
            return false;
        }

        // 3. 解析用户信息并存入 Request 属性（供后续 Controller/Service 使用）
        Long userId = JwtUtil.getUserId(token);
        String username = JwtUtil.getUsername(token);

        if (userId == null) {
            sendUnauthorized(response, "Token解析失败，请重新登录");
            return false;
        }

        request.setAttribute("currentUserId", userId);
        request.setAttribute("currentUsername", username);

        return true; // 放行
    }

    /**
     * 从请求头提取 Bearer Token
     */
    private String extractToken(HttpServletRequest request) {
        String header = request.getHeader(AUTH_HEADER);
        if (header != null && header.startsWith(TOKEN_PREFIX)) {
            return header.substring(TOKEN_PREFIX.length());
        }
        return null;
    }

    /**
     * 返回 401 未授权响应
     */
    private void sendUnauthorized(HttpServletResponse response, String message) throws Exception {
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType("application/json;charset=UTF-8");
        String json = "{\"code\":401,\"msg\":\"" + message + "\",\"data\":null}";
        response.getWriter().write(json);
    }
}
