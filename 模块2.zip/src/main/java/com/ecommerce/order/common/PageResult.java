package com.ecommerce.order.common;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 分页响应结果
 */
@Data
public class PageResult<T> implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 当前页码 */
    private Long current;
    /** 每页大小 */
    private Long size;
    /** 总记录数 */
    private Long total;
    /** 总页数 */
    private Long pages;
    /** 数据列表 */
    private List<T> records;

    public PageResult() {}

    public PageResult(long current, long size, long total, List<T> records) {
        this.current = current;
        this.size = size;
        this.total = total;
        // 计算总页数
        this.pages = (total + size - 1) / size;
        this.records = records;
    }
}
