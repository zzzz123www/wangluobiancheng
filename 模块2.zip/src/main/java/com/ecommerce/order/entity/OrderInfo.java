package com.ecommerce.order.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 订单主表实体类
 * 对应 order_info 表
 */
@Data
@TableName("order_info")
public class OrderInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 订单ID（主键） */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 订单编号（业务唯一键） */
    private String orderNo;

    /** 用户ID */
    private Long userId;

    /** 下单用户名 */
    private String username;

    /** 订单总金额（元） */
    private BigDecimal totalAmount;

    /** 实付金额（元） */
    private BigDecimal payAmount;

    /** 运费（元） */
    private BigDecimal freightAmount;

    /** 优惠减免（元） */
    private BigDecimal discountAmount;

    /** 订单状态：0待付款 1已付款 2已发货 3已完成 4已取消 5退款中 6已退款 */
    private Integer orderStatus;

    /** 支付方式：1支付宝 2微信 3银行卡 */
    private Integer payType;

    /** 支付时间 */
    private LocalDateTime payTime;

    /** 发货时间 */
    private LocalDateTime deliveryTime;

    /** 确认收货时间 */
    private LocalDateTime receiveTime;

    /** 订单完成时间 */
    private LocalDateTime finishTime;

    /** 取消时间 */
    private LocalDateTime cancelTime;

    /** 取消原因 */
    private String cancelReason;

    /** 收货人姓名 */
    private String receiverName;

    /** 收货人手机号 */
    private String receiverPhone;

    /** 省 */
    private String receiverProvince;

    /** 市 */
    private String receiverCity;

    /** 区/县 */
    private String receiverDistrict;

    /** 详细地址 */
    private String receiverAddress;

    /** 订单备注 */
    private String remark;

    /** 订单来源：1PC端 2APP端 3小程序 */
    private Integer source;

    /** 乐观锁版本号 */
    @Version
    private Integer version;

    /** 逻辑删除：0未删 1已删 */
    @TableLogic
    private Integer deleted;

    /** 创建时间 */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /** 更新时间 */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
