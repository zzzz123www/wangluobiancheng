package com.ecommerce.order.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 订单商品明细实体类
 * 对应 order_item 表
 */
@Data
@TableName("order_item")
public class OrderItem implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 明细ID（主键） */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 订单ID（关联 order_info.id） */
    private Long orderId;

    /** 订单编号 */
    private String orderNo;

    /** 商品ID */
    private Long productId;

    /** 商品名称 */
    private String productName;

    /** 商品图片URL */
    private String productImage;

    /** 规格SKU ID */
    private Long skuId;

    /** 规格名称 */
    private String skuName;

    /** 商品单价（元） */
    private BigDecimal unitPrice;

    /** 购买数量 */
    private Integer quantity;

    /** 小计金额（单价×数量） */
    private BigDecimal totalPrice;

    /** 逻辑删除：0未删 1已删 */
    @TableLogic
    private Integer deleted;

    /** 创建时间 */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    /** 更新时间 */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
