package com.ecommerce.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.ecommerce.order.entity.OrderInfo;
import org.apache.ibatis.annotations.Mapper;

/**
 * 订单主表 Mapper 接口
 * 继承 BaseMapper 获得 MyBatis Plus 内置 CRUD 能力
 */
@Mapper
public interface OrderInfoMapper extends BaseMapper<OrderInfo> {
}
