package com.ecommerce.order.config;

import com.ecommerce.order.interceptor.JwtAuthInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Web MVC 配置类
 * 1. 注册 JWT 拦截器，配置拦截路径与放行路径
 * 2. 全局跨域配置（CORS）
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    private final JwtAuthInterceptor jwtAuthInterceptor;

    public WebConfig(JwtAuthInterceptor jwtAuthInterceptor) {
        this.jwtAuthInterceptor = jwtAuthInterceptor;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(jwtAuthInterceptor)
                // 拦截所有 /api 路径
                .addPathPatterns("/api/**")
                // 放行登录和注册接口（无需 Token）
                .excludePathPatterns(
                        "/api/auth/login",
                        "/api/auth/register",
                        // 放行 Swagger/Knife4j 文档
                        "/doc.html",
                        "/swagger-ui/**",
                        "/v3/api-docs/**",
                        "/webjars/**"
                );
    }

    /**
     * 全局跨域配置
     * 允许前端跨域调用后端 API
     */
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOriginPatterns("*") // 允许所有来源（生产环境应指定域名）
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true)   // 允许携带 Cookie/Token
                .maxAge(3600);             // 预检请求缓存时间（秒）
    }
}
