package com.ecommerce.order.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Swagger / Knife4j 接口文档配置
 * 访问地址：http://localhost:8080/doc.html
 *
 * 工程化规范：所有接口自动生成文档，支持在线调试
 */
@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI openAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("电商购物平台 - 订单模块 API")
                        .description("### 功能模块\n\n" +
                                "- **用户认证**：登录、登出、获取当前用户信息\n" +
                                "- **订单管理**：CRUD + 多条件分页查询 + 状态流转\n\n" +
                                "### Token 验证说明\n\n" +
                                "除 `/api/auth/login` 外的所有接口均需在请求头中携带 JWT Token：\n" +
                                "`Authorization: Bearer <your_token>`\n\n" +
                                "### 联系方式\n" +
                                "作者：AI Assistant")
                        .version("v2.0.0")
                        .contact(new Contact()
                                .name("电商项目组")
                                .email("dev@ecommerce.com"))
                        .license(new License().name("MIT")))
                // 全局安全配置（JWT Bearer Token）
                .addSecurityItem(new SecurityRequirement().addList("BearerAuth"))
                .schemaComponents(new io.swagger.v3.oas.models.Components()
                        .addSecuritySchemes("BearerAuth",
                                new SecurityScheme()
                                        .type(SecurityScheme.Type.HTTP)
                                        .scheme("bearer")
                                        .bearerFormat("JWT")
                                        .description("JWT Token 认证，格式: Bearer <token>")));
    }
}
