package com.ecommerce.order;

import com.ecommerce.order.dto.AddOrderDTO;
import com.ecommerce.order.dto.OrderQueryDTO;
import com.ecommerce.order.dto.UpdateOrderDTO;
import com.ecommerce.order.entity.OrderInfo;
import com.ecommerce.order.service.IOrderService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigDecimal;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 订单模块 CRUD 接口测试
 */
@SpringBootTest
@DisplayName("订单模块接口测试")
class OrderApiTest {

    @Autowired
    private IOrderService orderService;

    private Long testOrderId;

    // ==================== 新增（Create） ====================

    @Test
    @DisplayName("1.1 新增订单 - 正常流程")
    void testAddOrder() {
        AddOrderDTO dto = new AddOrderDTO();
        dto.setUserId(9999L);
        dto.setUsername("测试用户");
        dto.setTotalAmount(new BigDecimal("599.00"));
        dto.setPayAmount(new BigDecimal("569.00"));
        dto.setFreightAmount(new BigDecimal("10.00"));
        dto.setDiscountAmount(new BigDecimal("30.00"));
        dto.setReceiverName("测试收货人");
        dto.setReceiverPhone("13800001111");
        dto.setReceiverProvince("广东省");
        dto.setReceiverCity("深圳市");
        dto.setReceiverDistrict("南山区");
        dto.setReceiverAddress("科技路100号");
        dto.setRemark("JUnit自动创建的测试订单");

        // 添加商品明细
        AddOrderDTO.OrderItemDTO item = new AddOrderDTO.OrderItemDTO();
        item.setProductId(5001L);
        item.setProductName("测试商品-无线充电器");
        item.setSkuName("白色/15W");
        item.setUnitPrice(new BigDecimal("99.00"));
        item.setQuantity(6);
        dto.setItems(Arrays.asList(item));

        OrderInfo result = orderService.add(dto);

        assertNotNull(result, "新增订单不应为空");
        assertNotNull(result.getId(), "新增后应生成主键ID");
        assertNotNull(result.getOrderNo(), "新增后应生成订单编号");
        assertEquals(0, result.getOrderStatus(), "新订单状态应为待付款(0)");
        assertEquals(new BigDecimal("599.00"), result.getTotalAmount());
        this.testOrderId = result.getId();

        System.out.println("[PASS] 1.1 新增订单成功，ID=" + result.getId() + "，单号=" + result.getOrderNo());
    }

    @Test
    @DisplayName("1.2 新增订单 - 缺少必填字段")
    void testAddOrderMissingRequired() {
        AddOrderDTO dto = new AddOrderDTO();
        // 不设置 userId 和 receiverName 等必填字段
        dto.setUsername("测试用户2");

        Exception exception = assertThrows(Exception.class, () -> {
            orderService.add(dto);
        });
        assertTrue(exception.getMessage().contains("用户名") || exception.getMessage().contains("不能为空"),
                "应抛出参数校验异常");

        System.out.println("[PASS] 1.2 缺少必填字段校验通过: " + exception.getMessage());
    }

    // ==================== 查询（Read） ====================

    @Test
    @DisplayName("2.1 根据ID查询订单详情")
    void testGetById() {
        OrderInfo order = orderService.getDetailById(1L);
        assertNotNull(order, "ID=1的订单应存在");
        assertNotNull(order.getOrderNo(), "订单号不应为空");
        assertEquals(3, order.getOrderStatus(), "ID=1的订单状态应为已完成(3)");

        System.out.println("[PASS] 2.1 查询订单详情成功，订单号=" + order.getOrderNo()
                + ", 状态=" + order.getOrderStatus() + ", 总金额=" + order.getTotalAmount());
    }

    @Test
    @DisplayName("2.2 根据订单号查询")
    void testGetByOrderNo() {
        OrderInfo order = orderService.getByOrderNo("ORD202405280001");
        assertNotNull(order, "该订单号应存在");
        assertEquals("张三", order.getUsername());

        System.out.println("[PASS] 2.2 根据订单号查询成功，用户=" + order.getUsername());
    }

    @Test
    @DisplayName("2.3 查询不存在的订单")
    void testGetByNotExistId() {
        OrderInfo order = orderService.getDetailById(99999L);
        assertNull(order, "不存在的订单应返回null");

        System.out.println("[PASS] 2.3 查询不存在的订单返回null，验证通过");
    }

    @Test
    @DisplayName("2.4 分页查询 - 全部订单")
    void testQueryPageAll() {
        OrderQueryDTO query = new OrderQueryDTO();
        query.setCurrent(1L);
        query.setSize(10L);

        var page = orderService.queryPage(query);

        assertNotNull(page, "分页结果不为空");
        assertTrue(page.getTotal() > 0, "总记录数应大于0");
        assertFalse(page.getRecords().isEmpty(), "当前页记录不应为空");

        System.out.println("[PASS] 2.4 分页查询成功，总条数=" + page.getTotal()
                + "，本页" + page.getRecords().size() + "条");
    }

    @Test
    @DisplayName("2.5 分页查询 - 按状态筛选")
    void testQueryPageByStatus() {
        OrderQueryDTO query = new OrderQueryDTO();
        query.setCurrent(1L);
        query.setSize(10L);
        query.setOrderStatus(3);  // 已完成

        var page = orderService.queryPage(query);

        assertNotNull(page);
        for (OrderInfo o : page.getRecords()) {
            assertEquals(3, o.getOrderStatus(), "所有结果应为已完成状态");
        }

        System.out.println("[PASS] 2.5 按状态筛选查询成功，共" + page.getTotal() + "条已完成订单");
    }

    @Test
    @DisplayName("2.6 分页查询 - 按用户ID筛选")
    void testQueryPageByUserId() {
        OrderQueryDTO query = new OrderQueryDTO();
        query.setCurrent(1L);
        query.setSize(10L);
        query.setUserId(1001L);  // 张三

        var page = orderService.queryPage(query);

        assertNotNull(page);
        for (OrderInfo o : page.getRecords()) {
            assertEquals(1001L, o.getUserId(), "所有结果应为张三的订单");
        }

        System.out.println("[PASS] 2.6 按用户ID筛选查询成功，张三共有" + page.getTotal() + "个订单");
    }

    @Test
    @DisplayName("2.7 分页查询 - 按手机号模糊搜索")
    void testQueryPageByPhone() {
        OrderQueryDTO query = new OrderQueryDTO();
        query.setCurrent(1L);
        query.setSize(10L);
        query.setReceiverPhone("138");  // 模糊搜索

        var page = orderService.queryPage(query);

        assertNotNull(page);
        for (OrderInfo o : page.getRecords()) {
            assertTrue(o.getReceiverPhone().contains("138"),
                    "搜索结果应包含138");
        }

        System.out.println("[PASS] 2.7 手机号模糊搜索成功，匹配" + page.getTotal() + "条");
    }

    // ==================== 修改（Update） ====================

    @Test
    @DisplayName("3.1 修改订单收货地址")
    void testUpdateOrder() {
        UpdateOrderDTO dto = new UpdateOrderDTO();
        dto.setId(3L);  // 待付款状态的订单
        dto.setReceiverName("修改后的收货人");
        dto.setReceiverPhone("13999999999");
        dto.setReceiverAddress("新地址888号");
        dto.setRemark("地址已更新");

        boolean success = orderService.update(dto);
        assertTrue(success, "修改应成功");

        // 验证修改后的数据
        OrderInfo updated = orderService.getDetailById(3L);
        assertEquals("修改后的收货人", updated.getReceiverName());

        System.out.println("[PASS] 3.1 订单地址修改成功");
    }

    @Test
    @DisplayName("3.2 修改不存在的订单")
    void testUpdateNotExist() {
        UpdateOrderDTO dto = new UpdateOrderDTO();
        dto.setId(99999L);
        dto.setReceiverName("不存在");

        assertThrows(RuntimeException.class, () -> orderService.update(dto),
                "修改不存在的订单应抛出异常");

        System.out.println("[PASS] 3.2 修改不存在的订单异常验证通过");
    }

    // ==================== 删除（Delete） ====================

    @Test
    @DisplayName("4.1 删除单个订单（逻辑删除）")
    void testDeleteOrder() {
        // 先创建一个待删除的订单
        AddOrderDTO dto = new AddOrderDTO();
        dto.setUserId(8888L);
        dto.setUsername("待删除用户");
        dto.setTotalAmount(new BigDecimal("1.00"));
        dto.setPayAmount(new BigDecimal("1.00"));
        dto.setReceiverName("删除目标");
        dto.setReceiverPhone("13000000000");
        dto.setReceiverAddress("测试地址");
        dto.setItems(Arrays.asList());

        OrderInfo created = orderService.add(dto);
        Long id = created.getId();

        // 执行删除
        boolean success = orderService.delete(id);
        assertTrue(success, "删除应成功");

        // 验证逻辑删除后查不到（MyBatis Plus 逻辑删除自动过滤）
        OrderInfo deleted = orderService.getDetailById(id);
        assertNull(deleted, "逻辑删除后查询应返回null");

        System.out.println("[PASS] 4.1 逻辑删除订单成功，ID=" + id);
    }

    @Test
    @DisplayName("4.2 批量删除订单")
    void testBatchDeleteOrders() {
        // 创建两个待批量删除的订单
        Long[] ids = new Long[2];
        for (int i = 0; i < 2; i++) {
            AddOrderDTO dto = new AddOrderDTO();
            dto.setUserId(7777L);
            dto.setUsername("批删用户" + i);
            dto.setTotalAmount(new BigDecimal("10.00"));
            dto.setPayAmount(new BigDecimal("10.00"));
            dto.setReceiverName("批删" + i);
            dto.setReceiverPhone("1310000000" + i);
            dto.setReceiverAddress("批删地址");
            dto.setItems(Arrays.asList());
            OrderInfo created = orderService.add(dto);
            ids[i] = created.getId();
        }

        // 执行批量删除
        boolean success = orderService.deleteBatch(ids);
        assertTrue(success, "批量删除应成功");

        for (Long id : ids) {
            assertNull(orderService.getDetailById(id), "批量删除后每个订单都应查不到");
        }

        System.out.println("[PASS] 4.2 批量删除" + ids.length + "个订单成功");
    }

    // ==================== 综合场景 ====================

    @Test
    @DisplayName("5.1 完整生命周期：新增→查询→修改→删除")
    void testFullLifecycle() {
        // Step 1: 新增
        AddOrderDTO dto = new AddOrderDTO();
        dto.setUserId(6666L);
        dto.setUsername("生命周期用户");
        dto.setTotalAmount(new BigDecimal("200.00"));
        dto.setPayAmount(new BigDecimal("190.00"));
        dto.setFreightAmount(BigDecimal.TEN);
        dto.setReceiverName("LC用户");
        dto.setReceiverPhone("13200006666");
        dto.setReceiverAddress("LC测试地址");

        AddOrderDTO.OrderItemDTO item = new AddOrderDTO.OrderItemDTO();
        item.setProductId(6001L);
        item.setProductName("LC测试商品");
        item.setUnitPrice(new BigDecimal("95.00"));
        item.setQuantity(2);
        dto.setItems(Arrays.asList(item));

        OrderInfo created = orderService.add(dto);
        assertNotNull(created.getId());
        Long orderId = created.getId();
        System.out.println("  [Step1 新增] ID=" + orderId + " 单号=" + created.getOrderNo());

        // Step 2: 按ID查询
        OrderInfo found = orderService.getDetailById(orderId);
        assertEquals(created.getOrderNo(), found.getOrderNo());
        assertEquals("生命周期用户", found.getUsername());
        System.out.println("  [Step2 查询] 验证订单信息一致");

        // Step 3: 按单号查询
        OrderInfo byNo = orderService.getByOrderNo(created.getOrderNo());
        assertNotNull(byNo);
        assertEquals(orderId, byNo.getId());
        System.out.println("  [Step3 按单号查询] 单号=" + created.getOrderNo() + " 匹配正确");

        // Step 4: 修改
        UpdateOrderDTO updateDto = new UpdateOrderDTO();
        updateDto.setId(orderId);
        updateDto.setReceiverName("LC修改后");
        updateDto.setRemark("生命周期修改测试");
        orderService.update(updateDto);

        OrderInfo updated = orderService.getDetailById(orderId);
        assertEquals("LC修改后", updated.getReceiverName());
        System.out.println("  [Step4 修改] 收货人更新为: " + updated.getReceiverName());

        // Step 5: 在列表中能搜到
        OrderQueryDTO query = new OrderQueryDTO();
        query.setUserId(6666L);
        var page = orderService.queryPage(query);
        assertTrue(page.getTotal() >= 1, "列表中应包含该订单");
        System.out.println("  [Step5 列表搜索] 用户6666的订单数=" + page.getTotal());

        // Step 6: 删除
        orderService.delete(orderId);
        assertNull(orderService.getDetailById(orderId), "删除后不应再查到");
        System.out.println("  [Step6 删除] 订单已逻辑删除，查询返回null");

        System.out.println("[PASS] 5.1 完整生命周期测试全部通过！");
    }
}
