# 电商购物平台 - 订单模块（含用户认证）

> **技术栈**：SpringBoot 3.2.5 + MyBatis Plus 3.5.6 + JWT (jjwt 0.12.5) + Knife4j 4.4.0
>
> **Java 版本**：JDK 17

---

## 功能模块

| 模块 | 说明 | 状态 |
|------|------|:----:|
| **用户认证** | 登录 / 登出 / 获取当前用户 / JWT Token 验证 | ✅ |
| **订单 CRUD** | 新增 / 查询(按ID/单号) / 修改 / 删除(逻辑) / 批量删除 | ✅ |
| **订单列表** | 多条件分页查询（10+筛选条件）+ 动态排序 | ✅ |
| **状态流转** | 待付款 → 已付款 → 已发货 → 已完成 / 取消 | ✅ |
| **接口文档** | Swagger/Knife4j 在线调试文档 | ✅ |
| **全局异常** | 统一异常处理（参数校验/业务/运行时） | ✅ |

## 项目结构

```
src/main/java/com/ecommerce/order/
├── OrderApplication.java          # 启动类 (@MapperScan)
│
├── config/
│   ├── MybatisPlusConfig.java     # 分页插件 + 自动填充
│   ├── WebConfig.java             # JWT拦截器注册 + CORS跨域
│   └── SwaggerConfig.java         # 接口文档配置
│
├── controller/
│   ├── AuthController.java        # 认证接口（登录/登出）
│   └── OrderController.java       # 订单 CRUD 接口
│
├── service/
│   ├── IUserService.java          # 用户服务接口
│   ├── IOrderService.java         # 订单服务接口
│   └── impl/
│       ├── UserServiceImpl.java   # 用户服务实现（登录逻辑）
│       └── OrderServiceImpl.java  # 订单服务实现（CRUD + 分页查询）
│
├── mapper/
│   ├── UserInfoMapper.java        # 用户 Mapper
│   ├── OrderInfoMapper.java       # 订单主表 Mapper
│   └── OrderItemMapper.java       # 订单明细 Mapper
│
├── entity/
│   ├── UserInfo.java              # 用户实体
│   ├── OrderInfo.java             # 订单实体
│   └── OrderItem.java             # 订单明细实体
│
├── dto/
│   ├── LoginDTO.java              # 登录请求
│   ├── LoginVO.java               # 登录响应（含Token）
│   ├── AddOrderDTO.java           # 新增订单
│   ├── UpdateOrderDTO.java        # 修改订单
│   └── OrderQueryDTO.java         # 订单查询条件（增强版）
│
├── interceptor/
│   └── JwtAuthInterceptor.java    # JWT Token 认证拦截器
│
├── util/
│   └── JwtUtil.java               # JWT 工具类
│
└── common/
    ├── Result.java                # 统一响应
    ├── PageResult.java            # 分页结果
    └── GlobalExceptionHandler.java # 全局异常处理
```

## 快速启动

### 1. 数据库初始化
```bash
mysql -u root -proot < sql/user_auth.sql      # 用户认证表 + 测试数据
mysql -u root -proot < sql/order_module.sql    # 订单表 + 测试数据
```

### 2. IDEA 启动
- 打开 `OrderApplication.java` → 右键 Run

### 3. 测试登录获取 Token
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"123456"}'
```

### 4. 使用 Token 调用订单接口
```bash
# 查询订单列表（需替换 <token> 为上一步返回的 token）
curl "http://localhost:8080/api/order/list?current=1&size=10" \
  -H "Authorization: Bearer <token>"
```

### 5. 在线接口文档
浏览器打开：**http://localhost:8080/doc.html**

## 默认测试账号

| 用户名 | 密码 | 角色 | 手机号 |
|--------|------|------|--------|
| admin | 123456 | 管理员 | 13800000001 |
| zhangsan | 123456 | 普通用户 | 13800000002 |
| lisi | 123456 | 普通用户 | 13800000003 |
| wangwu | 123456 | 普通用户 | 13800000004 |
| operator1 | 123456 | 运营 | 13800000005 |

## 文档清单

| 文档 | 内容 |
|------|------|
| `docs/01-实现思路.md` | 技术选型、架构设计、API 表 |
| `docs/02-表结构.md` | 数据库表设计说明 |
| `docs/03-接口代码说明.md` | 各层代码实现详解 |
| `docs/04-测试报告.md` | 接口测试用例与结果 |
| `docs/05-登录验证原理说明.md` | **JWT Token 原理、结构、流程图** |
| `docs/06-查询功能前后端过程说明.md` | **6层时序图、各层职责、条件一览表** |
| `docs/07-AI提问记录.md` | **AI 交互完整记录** |
